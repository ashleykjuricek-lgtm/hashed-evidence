# threeanswer

A plotter that gives one of three answers for every column of pixels, and never
draws a confident line through something it cannot resolve.

```
python -m threeanswer "tan(1/x)" --x -1 1 --y -6 6 --out tan.png
python -m threeanswer "1/x" --x -3 3 --y -5 5 --ascii
python -m threeanswer "x**2 + y**2 - 1" --relation --x -2 2 --y -2 2 --out circle.png
python -m threeanswer "1/(x*y)" --surface --x -2 2 --y -2 2 --out hyper.png
python demo.py          # writes the gallery into ./out/
python -m pytest -q     # 40-odd tests, including soundness by random sampling
```

Needs Python 3.9+, `mpmath`, `numpy`, and `matplotlib` for PNG output. All three are
in a stock Anaconda.

## The three answers

Ask "what values does this formula take over this whole stretch of x?" and you get
back one of:

| answer | meaning | drawn as |
|---|---|---|
| **Bounded(lo, hi)** | every value on the column lies inside [lo, hi] | ink, as the vertical box it is |
| **Unbounded** | the values run off to infinity somewhere in the column: a pole, or detail finer than the column | a red column |
| **Undefined** | the formula has no real value anywhere in the column | paper, nothing |

And the law for combining them, written once:

> Undefined absorbs. Then Unbounded spills. Then the arithmetic runs.

A column with no values is not a column with infinite ones. `log` of a wholly
negative column is a gap, not a pole. `sqrt` of a column that is only partly
negative encloses its defined part rather than punching a false gap into a curve
that exists.

## Why not sample points

The usual plotter evaluates at N points and joins them. Two failures, and the
second is fatal:

- **Sparse poles.** `1/x` near zero returns a huge finite number and the polyline
  draws straight through the asymptote. Breaking the line fixes this one.
- **Dense poles.** `tan(1/x)` has infinitely many asymptotes in any neighbourhood
  of zero. Between two adjacent samples there can be thousands. No sample count
  detects them. Point sampling is not incomplete here; it is blind in principle.

Evaluating over the column with interval arithmetic returns an **enclosure**: a
range that provably contains every value the formula takes there. It may be fat.
It is never wrong. Endpoints round outward. The pole is found by the arithmetic
(division by a range that contains zero), not by a root-finder.

## The one known leak, kept on purpose

Interval arithmetic forgets that the two `x`'s in `x/x` are the same `x`, so on a
column containing zero it reports a pole that is not there. The direction of that
error is the one a plotter wants: over-warn, never draw through a real
singularity. The test `test_the_dependency_problem_widens_rather_than_misses`
pins it so nobody "fixes" it into a lie.

## Refinement

An Unbounded column is halved, up to `--depth` times, and each half is asked
again. A single pole shrinks to the sliver that contains it, with ordinary curve
on either side. A dense mess stays Unbounded at every cut, and at the finest cut
that answer is final: a solid red block that honestly says "there is detail here
finer than a pixel."

## Polar mode, for roses and tails

```
python -m threeanswer "cos(2*theta)" --polar --x -1.3 1.3 --y -1.3 1.3 --out rose.png
python -m threeanswer "sin(5*theta/2)" --polar --theta 0 4 --out rose52.png
```

The angle is cut into arcs the way x was cut into columns (`--arcs`, default 720,
refined by `--depth`). Each arc gets the same three answers for r:

| answer | drawn as |
|---|---|
| Bounded(rlo, rhi) | the annular sector between those radii on that arc |
| Unbounded | the whole ray at that arc, in red |
| Undefined | nothing |

Negative r is folded across to the opposite angle exactly, not clipped and not
abs'd, so even-petal roses come out whole. `--theta` is in multiples of pi, so a
half-integer rose is `--theta 0 4`. Pixels are painted by cell, not by centre: a
curve that clips a pixel's corner still paints it. The test
`test_every_point_of_the_true_curve_lands_on_a_painted_pixel` samples 300 points
of each true curve and asks that every one of them is painted.

This is the mode the project needed: a direction-dependent object gets its shape
and its tails drawn as they are, with poles and gaps kept distinct, instead of
being reduced to a scalar mean and called a null.

## Layout

```
threeanswer/enclosure.py   the three answers and the arithmetic on them
threeanswer/expr.py        expression nodes that enclose themselves; the parser
threeanswer/plot.py        Frame, columns/cells, classify, refine
threeanswer/render.py      spans to pixels; knows nothing about algebra
threeanswer/polar.py       r = f(theta): arcs, sectors, negative-r folding, cell painting
threeanswer/__main__.py    the command line
tests/                     pytest
demo.py                    the gallery
```

Dependencies point one way: render → plot → expr → enclosure.

## Precision, stated plainly

Endpoints are binary floating-point numbers at mpmath's working precision (53
bits unless you raise `mpmath.mp.prec`), rounded outward by mpmath's interval
type. They are not exact rationals. The soundness claim is: at that precision,
the true values are inside the reported range. The random-sampling tests check
this on ten formulas over hundreds of columns each.

## Where this came from

- **Technique:** Jeff Tupper, *Reliable Two-Dimensional Graphing Methods for
  Mathematical Formulae with Two Free Variables*, SIGGRAPH 2001. The algorithm
  behind GrafEq.
- **Design:** James Watkins's public `vexelray-gui-plot` module
  (`github.com/sibarum/vexelray-gui`, master branch, `docs/reliable-plotting.md`)
  carries the same three answers and the same absorb/spill law, in Java. This is
  a re-implementation of that idea in Python, written from the public docs and
  source, not a port of his code. That repository has no license file, so no code
  was copied.
- **Written by:** Claude (Fable 5.1) for Ash Juricek, 2026-09-06, as part of the
  Unsmoothed / HEM project. The three-answer discipline is the project's
  "preserve distinctions" rule applied to a plotter: a gap, a pole, and a value
  are three different things, and merging them silently is the error.
