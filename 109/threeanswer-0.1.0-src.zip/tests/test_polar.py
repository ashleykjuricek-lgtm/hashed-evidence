"""Polar mode: roses, negative r, poles on rays, gaps, and never-miss by sampling."""

import math
import random

import numpy as np
import pytest

from threeanswer import parse, Frame, raster_polar
from threeanswer.render import INK, POLE, PAPER
from threeanswer.polar import sectors, arcs
from threeanswer.expr import evaluate_float

SQ = Frame(-1.5, 1.5, -1.5, 1.5)


def _painted(img, x, y, frame, kinds=(INK, POLE)):
    h, w = img.shape[:2]
    c = int((x - frame.x0) / (frame.x1 - frame.x0) * w)
    r = int((frame.y1 - y) / (frame.y1 - frame.y0) * h)
    c = min(max(c, 0), w - 1); r = min(max(r, 0), h - 1)
    px = img[r, c]
    return any(np.allclose(px, k) for k in kinds)


def test_arcs_touch_or_overlap_never_gap():
    a = arcs(0, 2, 90)
    assert len(a) == 90
    for p, q in zip(a, a[1:]):
        assert p.hi >= q.lo


def test_unit_circle_is_a_ring():
    img = raster_polar(parse("1"), SQ, 90, 90, axes=False)
    assert _painted(img, 1, 0, SQ) and _painted(img, 0, 1, SQ) and _painted(img, -1, 0, SQ)
    assert np.allclose(img[45, 45], PAPER)          # centre is paper
    assert np.allclose(img[2, 2], PAPER)            # corner is paper


def test_negative_r_is_folded_across_not_clipped():
    # r = -1 is the same circle as r = 1
    img = raster_polar(parse("-1"), SQ, 90, 90, axes=False)
    assert _painted(img, 1, 0, SQ) and _painted(img, 0, -1, SQ)
    assert np.allclose(img[45, 45], PAPER)


def test_four_petal_rose_has_all_four_petals_and_passes_through_the_origin():
    img = raster_polar(parse("cos(2*theta)"), SQ, 120, 120, axes=False)
    for (x, y) in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        assert _painted(img, x, y, SQ), (x, y)
    assert _painted(img, 0, 0, SQ)
    # and the diagonal at distance 1 is empty (petal tips are on the axes only)
    d = math.sqrt(0.5)
    assert not _painted(img, d, d, SQ)


def test_pole_on_a_ray():
    # r = 1/cos(theta) is the vertical line x = 1; cos -> 0 at theta = pi/2, a pole on that ray
    img = raster_polar(parse("1/cos(theta)"), SQ, 120, 120, axes=False)
    assert _painted(img, 1, 0.5, SQ) and _painted(img, 1, -0.5, SQ)   # the line
    assert _painted(img, 0, 1.2, SQ, kinds=(POLE,))                   # the pole ray up
    assert _painted(img, 0, -1.2, SQ, kinds=(POLE,))                  # and down


def test_true_gap_paints_nothing():
    # r = sqrt(cos(theta)): no real value where cos < 0, i.e. the whole left half-plane
    img = raster_polar(parse("sqrt(cos(theta))"), SQ, 120, 120, axes=False)
    left = img[:, :50]
    assert np.allclose(left, PAPER)
    assert _painted(img, 1, 0, SQ)


def test_undefined_arcs_produce_no_sectors():
    secs = sectors(parse("sqrt(cos(theta))"), 0, 2, 360, 4, 3.0)
    for s in secs:
        # an arc that touches the edge of the gap may enclose its defined sliver (partial domain);
        # an arc wholly inside the gap must not appear at all
        assert max(math.cos(s.tlo), math.cos(s.thi)) > -1e-6, s


@pytest.mark.parametrize("formula,t1", [
    ("cos(2*theta)", 2), ("cos(3*theta)", 2), ("sin(5*theta/2)", 4),
    ("1 + 2*cos(theta)", 2), ("theta/4", 2), ("1/cos(theta) - 1", 2),
])
def test_every_point_of_the_true_curve_lands_on_a_painted_pixel(formula, t1):
    rng = random.Random(7)
    e = parse(formula)
    img = raster_polar(e, SQ, 150, 150, 0, t1, n_arcs=360, depth=5, axes=False)
    for _ in range(300):
        t = rng.uniform(0, t1 * math.pi)
        r = evaluate_float(e, {"theta": t})
        if r is None or not math.isfinite(r):
            continue
        x, y = r * math.cos(t), r * math.sin(t)
        if not (SQ.x0 < x < SQ.x1 and SQ.y0 < y < SQ.y1):
            continue
        assert _painted(img, x, y, SQ), (formula, t, r, x, y)
