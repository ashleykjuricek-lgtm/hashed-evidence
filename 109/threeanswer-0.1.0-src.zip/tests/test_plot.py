"""Classification, refinement, and the pictures."""

import numpy as np

from threeanswer import Bounded, Unbounded, Undefined, parse, Frame
from threeanswer.plot import classify, refine, Curve, Fill, Blank, columns
from threeanswer.render import raster_curve, raster_relation, ascii_curve, INK, POLE, PAPER


def test_classify_the_three_answers():
    assert isinstance(classify(Undefined(), -1, 1), Blank)
    assert classify(Undefined(), -1, 1).reason == "undefined"
    assert isinstance(classify(Unbounded(), -1, 1), Fill)
    c = classify(Bounded.of(0, 0.5), -1, 1)
    assert isinstance(c, Curve) and abs(c.bottom - 0.5) < 1e-12 and abs(c.top - 0.75) < 1e-12


def test_out_of_view_is_blank_but_not_undefined():
    b = classify(Bounded.of(5, 6), -1, 1)
    assert isinstance(b, Blank) and b.reason == "out-of-view"


def test_columns_touch_exactly():
    cs = columns(Frame(-1, 1, 0, 1), 7)
    assert len(cs) == 7
    for a, b in zip(cs, cs[1:]):
        assert a.hi == b.lo


def test_refine_separates_a_single_pole_from_the_finite_stretches():
    e = parse("1/x")
    pieces = refine(e, Bounded.of(-1, 1), depth=6)
    kinds = [type(enc).__name__ for _, enc in pieces]
    # most of the column is bounded now; only the slivers touching zero stay unbounded
    assert kinds.count("Unbounded") <= 2
    assert kinds.count("Bounded") >= 2


def test_refine_leaves_a_dense_mess_honestly_unbounded():
    e = parse("tan(1/x)")
    pieces = refine(e, Bounded.of(-0.01, 0.01), depth=6)
    assert all(isinstance(enc, Unbounded) for _, enc in pieces)


def test_undefined_is_never_refined():
    e = parse("log(x)")
    pieces = refine(e, Bounded.of(-2, -1), depth=6)
    assert len(pieces) == 1 and isinstance(pieces[0][1], Undefined)


def test_curve_picture_never_draws_through_the_pole():
    # 1/x on [-2,2]: the column containing zero must be a pole column, not ink joining the branches
    img = raster_curve(parse("1/x"), Frame(-2, 2, -4, 4), 41, 41, depth=6, axes=False)
    mid_col = img[:, 20]
    assert np.allclose(mid_col, POLE)
    # and the columns away from zero carry ink but no pole colour
    left = img[:, 5]
    assert (np.all(left == INK, axis=1)).any()
    assert not (np.all(left == POLE, axis=1)).any()


def test_gap_columns_are_paper():
    img = raster_curve(parse("log(x)"), Frame(-2, 2, -3, 1), 40, 20, depth=4, axes=False)
    left_half = img[:, :19]
    assert np.allclose(left_half, PAPER)


def test_relation_paints_the_unit_circle_and_nothing_inside():
    img = raster_relation(parse("x**2 + y**2 - 1"), Frame(-2, 2, -2, 2), 80, 80, axes=False)
    centre = img[40, 40]
    assert np.allclose(centre, PAPER)
    # somewhere on the ring there is ink
    assert (np.all(img == INK, axis=2)).sum() > 40


def test_ascii_smoke():
    s = ascii_curve(parse("sin(x)"), Frame(-6, 6, -1.5, 1.5), 48, 12)
    assert "#" in s and "|" not in s
