"""The arithmetic: the three answers and the law that joins them."""

import math
import random
from fractions import Fraction

import pytest

from threeanswer import Bounded, Unbounded, Undefined, parse
from threeanswer.expr import evaluate_float


def B(lo, hi):
    return Bounded.of(lo, hi)


# --- construction ------------------------------------------------------------

def test_inverted_interval_is_rejected():
    with pytest.raises(ValueError):
        Bounded.of(2, 1)


def test_endpoints_round_outward():
    third = Bounded.point(1).div(Bounded.point(3))
    assert third.contains(Fraction(1, 3))
    assert third.lo < third.hi  # it is fat, not a point


# --- the propagation law ---------------------------------------------------

def test_undefined_absorbs_everything():
    u = Undefined()
    assert isinstance(u.add(B(1, 2)), Undefined)
    assert isinstance(B(1, 2).mul(u), Undefined)
    assert isinstance(u.add(Unbounded()), Undefined)
    assert isinstance(Unbounded().add(u), Undefined)


def test_spill_does_not_turn_a_gap_into_a_pole():
    # A column with no values is not a column with infinite ones.
    assert isinstance(Undefined().spill(), Undefined)
    assert isinstance(Undefined().div(B(0, 0)), Undefined)


def test_unbounded_spills_through_arithmetic():
    assert isinstance(Unbounded().add(B(1, 2)), Unbounded)
    assert isinstance(B(1, 2).mul(Unbounded()), Unbounded)
    assert isinstance(Unbounded().exp(), Unbounded)
    assert isinstance(Unbounded().power(Fraction(3)), Unbounded)


def test_sin_and_cos_bound_the_unbounded():
    s = Unbounded().sin()
    assert isinstance(s, Bounded) and s.lo == -1 and s.hi == 1


# --- poles, gaps, partial domains ---------------------------------------------

def test_division_by_a_range_straddling_zero_is_a_pole():
    assert isinstance(B(1, 1).div(B(-1, 1)), Unbounded)
    assert isinstance(B(1, 1).div(B(0, 1)), Unbounded)   # touching zero counts
    assert isinstance(B(1, 1).div(B(1, 2)), Bounded)


def test_log_of_a_wholly_negative_column_is_a_true_gap():
    assert isinstance(B(-4, -1).log(), Undefined)


def test_log_of_a_column_touching_zero_spills():
    assert isinstance(B(-1, 2).log(), Unbounded)
    assert isinstance(B(0, 2).log(), Unbounded)


def test_sqrt_partial_domain_encloses_the_defined_part():
    r = B(-1, 4).sqrt()
    assert isinstance(r, Bounded)
    assert r.lo <= 0 and r.hi >= 2 and r.hi < 2.0001


def test_sqrt_wholly_negative_is_a_gap():
    assert isinstance(B(-4, -1).sqrt(), Undefined)


def test_tan_across_a_pole_is_unbounded_and_between_poles_is_bounded():
    assert isinstance(B(1, 2).tan(), Unbounded)        # pi/2 is inside
    t = B(0.1, 0.5).tan()
    assert isinstance(t, Bounded) and t.contains(math.tan(0.3))


def test_even_powers_are_sign_aware():
    sq = B(-2, 3).power(Fraction(2))
    assert sq.lo == 0 and sq.hi == 9


def test_negative_integer_power_touching_zero_is_a_pole():
    assert isinstance(B(-1, 1).power(Fraction(-1)), Unbounded)
    assert isinstance(B(1, 2).power(Fraction(-2)), Bounded)


def test_even_root_domain_rules():
    assert isinstance(B(-4, -1).power(Fraction(1, 2)), Undefined)
    part = B(-1, 4).power(Fraction(1, 2))
    assert isinstance(part, Bounded) and part.hi >= 2


def test_odd_root_is_defined_on_negatives():
    r = B(-8, 8).power(Fraction(1, 3))
    assert isinstance(r, Bounded) and r.contains(-2) and r.contains(2)


# --- the known leak, pinned so nobody "fixes" it into a lie -------------------

def test_the_dependency_problem_widens_rather_than_misses():
    # x/x is 1 everywhere except at 0, but interval arithmetic forgets that the two
    # x's are the same x, so on a column containing zero it reports a pole it does
    # not have.  That is the direction of error a plotter wants: over-warn, never
    # draw through a real singularity.
    e = parse("x/x")
    assert isinstance(e.enclose_column(B(-1, 1)), Unbounded)
    away = e.enclose_column(B(1, 2))
    assert isinstance(away, Bounded) and away.contains(1)


# --- soundness by sampling: the true value is always inside the enclosure ----

FORMULAS = [
    "x**2 - 3*x + 1", "sin(x)*cos(3*x)", "exp(-x**2)", "1/(1+x**2)", "sqrt(abs(x))",
    "log(x**2 + 1)", "x**3 - x", "tan(x)/(1+x**2)", "abs(x - 1) + 0.5", "(x+1)**(1/3)",
]


@pytest.mark.parametrize("formula", FORMULAS)
def test_sampled_values_lie_inside_the_enclosure(formula):
    rng = random.Random(20260906)
    e = parse(formula)
    for _ in range(40):
        lo = rng.uniform(-4, 4)
        hi = lo + rng.uniform(1e-3, 0.5)
        enc = e.enclose_column(B(lo, hi))
        for _ in range(8):
            x = rng.uniform(lo, hi)
            v = evaluate_float(e, {"x": x})
            if v is None or not math.isfinite(v):
                continue  # the sample itself has no real answer; the enclosure must not be Bounded-and-miss
            if isinstance(enc, Bounded):
                tol = 1e-9 * max(1.0, abs(v))
                assert float(enc.lo) - tol <= v <= float(enc.hi) + tol, (formula, lo, hi, x, v, enc)
            else:
                # Unbounded/Undefined never *misses*: they claim nothing about a finite value
                assert isinstance(enc, Unbounded) or isinstance(enc, Undefined)
