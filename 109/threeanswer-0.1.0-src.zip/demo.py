"""
Make the demonstration pictures.  Run:  python demo.py
Writes PNGs into ./out/.
"""

import os
import time

from threeanswer import parse, Frame, raster_curve, raster_relation, raster_surface, raster_polar, save_png

OUT = os.path.join(os.path.dirname(__file__), "out")
os.makedirs(OUT, exist_ok=True)

CURVES = [
    ("1/x",                Frame(-3, 3, -6, 6),      "sparse pole: one red column at zero, nothing joined across it"),
    ("tan(1/x)",           Frame(-1, 1, -6, 6),      "dense poles: solid red near zero, because the detail is finer than a pixel"),
    ("log(x)",             Frame(-3, 3, -4, 2),      "true gap: paper on the left, a pole column at zero, curve on the right"),
    ("x/x",                Frame(-2, 2, -1, 3),      "the known leak: a pole reported at zero that is not there (over-warn, never miss)"),
    ("sin(1/x)",           Frame(-1, 1, -1.5, 1.5),  "no pole, but oscillation finer than a pixel becomes a solid band of ink, honestly"),
    ("sqrt(x) + sqrt(-x)", Frame(-2, 2, -1, 2),      "defined only at the single point zero; everywhere else a gap"),
    ("x**2 - 2",           Frame(-3, 3, -3, 7),      "a tame curve, drawn as the vertical boxes it is"),
]

RELATIONS = [
    ("x**2 + y**2 - 1",           Frame(-1.5, 1.5, -1.5, 1.5), "unit circle"),
    ("sin(x*y) - cos(x + y)",     Frame(-6, 6, -6, 6),         "Tupper-style relation graph"),
    ("y - tan(x)",                Frame(-6, 6, -6, 6),         "tan as a relation: the poles show as 'maybe' cells, never as ink joining branches"),
    ("y**2 - x**3 + x",           Frame(-2, 3, -3, 3),         "elliptic curve"),
]

SQ = Frame(-1.3, 1.3, -1.3, 1.3)
POLARS = [
    ("cos(2*theta)",        0, 2, SQ,                          "four-petal rose; the negative-r petals are folded across exactly"),
    ("cos(3*theta)",        0, 2, SQ,                          "three petals"),
    ("sin(5*theta/2)",      0, 4, SQ,                          "a half-integer rose needs two turns; --theta 0 4"),
    ("1 + 2*cos(theta)",    0, 2, Frame(-1.5, 3.3, -2.4, 2.4), "limacon with an inner loop"),
    ("1/cos(theta)",        0, 2, Frame(-2, 2, -2, 2),         "the line x = 1 in polar; the pole at theta = pi/2 is a red ray, not a stray point"),
    ("tan(theta)",          0, 2, Frame(-2, 2, -2, 2),         "poles on two rays; the tails reach them and stop"),
    ("1/(theta - 1)",       0, 2, Frame(-3, 3, -3, 3),         "a pole on one ray and a spiral tail either side; nothing is averaged"),
    ("sqrt(cos(theta))",    0, 2, SQ,                          "a true gap over the whole left half-plane"),
    ("cos(2*theta)/cos(theta)", 0, 2, Frame(-2, 2, -2, 2),     "a rose divided by a line: poles on the vertical, petals elsewhere"),
]

SURFACES = [
    ("1/(x*y)",                   Frame(-2, 2, -2, 2), "poles along both axes, coloured as poles not as huge numbers"),
    ("log(x*y)",                  Frame(-2, 2, -2, 2), "two quadrants are a true gap; the axes are a pole"),
    ("exp(-(x**2 + y**2))",       Frame(-3, 3, -3, 3), "a plain bump"),
]


def run():
    t0_clock = time.time()
    for f, frame, note in CURVES:
        img = raster_curve(parse(f), frame, 720, 420, depth=7)
        path = save_png(img, os.path.join(OUT, f"curve_{_slug(f)}.png"), f"y = {f}")
        print(f"{time.time()-t0_clock:6.1f}s  {path}\n         {note}")
    for f, frame, note in RELATIONS:
        img = raster_relation(parse(f), frame, 240, 240)
        path = save_png(img, os.path.join(OUT, f"relation_{_slug(f)}.png"), f"{f} = 0")
        print(f"{time.time()-t0_clock:6.1f}s  {path}\n         {note}")
    for f, t0, t1, frame, note in POLARS:
        img = raster_polar(parse(f), frame, 480, 480, t0, t1, n_arcs=1080, depth=6)
        path = save_png(img, os.path.join(OUT, f"polar_{_slug(f)}.png"), f"r = {f}   theta in [{t0}pi, {t1}pi]")
        print(f"{time.time()-t0_clock:6.1f}s  {path}\n         {note}")
    for f, frame, note in SURFACES:
        img = raster_surface(parse(f), frame, 160, 160)
        path = save_png(img, os.path.join(OUT, f"surface_{_slug(f)}.png"), f"z = {f}")
        print(f"{time.time()-t0_clock:6.1f}s  {path}\n         {note}")


def _slug(s):
    return "".join(c if c.isalnum() else "_" for c in s).strip("_")[:40]


if __name__ == "__main__":
    run()
