"""
From an enclosure to a picture, without knowing what a picture is made of.

Frame       the rectangle of plot space on show
columns()   cut the frame's x-range into pixel columns
cells()     cut the frame into pixel cells (two variables)
classify()  (enclosure, visible extent) -> Span: a clipped stretch of curve,
            a painted pole, or nothing
refine()    split an Unbounded column to tell a single pole from detail
            finer than the column; what stays Unbounded at the finest cut
            is honestly a solid block

A reliable plot has no diagonals in it: a column classifies to a VERTICAL SPAN,
and a vertical span is a box.  Point sampling needs polylines because it joins
samples it did not evaluate between.  Evaluating over the column removes the
need to join.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, Iterator, List, Tuple

from .enclosure import Enclosure, Bounded, Unbounded, Undefined
from .expr import Expr


@dataclass(frozen=True)
class Frame:
    """Plot space on show: x in [x0, x1], y in [y0, y1]."""
    x0: float
    x1: float
    y0: float
    y1: float

    def __post_init__(self):
        if not (self.x0 < self.x1 and self.y0 < self.y1):
            raise ValueError("frame must have positive width and height")


# --------------------------------------------------------------------------- #
# spans: the three things a column can be on screen
# --------------------------------------------------------------------------- #

class Span:
    pass


@dataclass(frozen=True)
class Curve(Span):
    """A clipped stretch of curve: fractions of the visible height, 0 = bottom, 1 = top."""
    bottom: float
    top: float


@dataclass(frozen=True)
class Fill(Span):
    """A painted pole: the whole column, because the values run off the top and bottom."""


@dataclass(frozen=True)
class Blank(Span):
    """Nothing here.  Either the curve exists but is out of view, or there is no curve."""
    reason: str  # "out-of-view" or "undefined"


def classify(enclosure: Enclosure, visible_lo: float, visible_hi: float) -> Span:
    """Clip an enclosure to the visible extent."""
    if isinstance(enclosure, Undefined):
        return Blank("undefined")
    if isinstance(enclosure, Unbounded):
        return Fill()
    lo, hi = float(enclosure.lo), float(enclosure.hi)
    if hi < visible_lo or lo > visible_hi:
        return Blank("out-of-view")
    h = visible_hi - visible_lo
    bottom = (max(lo, visible_lo) - visible_lo) / h
    top = (min(hi, visible_hi) - visible_lo) / h
    return Curve(_clamp01(bottom), _clamp01(top))


def _clamp01(v: float) -> float:
    return 0.0 if v < 0 else 1.0 if v > 1 else v


# --------------------------------------------------------------------------- #
# cutting the frame
# --------------------------------------------------------------------------- #

def _split(lo: float, hi: float, n: int) -> List[Bounded]:
    """Cut [lo, hi] into n touching stretches.  Endpoints are exact rationals so neighbours share edges."""
    lo_f, hi_f = Fraction(lo), Fraction(hi)
    step = (hi_f - lo_f) / n
    return [Bounded.of(lo_f + i * step, lo_f + (i + 1) * step) for i in range(n)]


def columns(frame: Frame, width: int) -> List[Bounded]:
    return _split(frame.x0, frame.x1, width)


def cells(frame: Frame, width: int, height: int) -> Iterator[Tuple[int, int, Dict[str, Bounded]]]:
    """Yield (column index, row index from the bottom, cell) for a width x height grid."""
    xs = _split(frame.x0, frame.x1, width)
    ys = _split(frame.y0, frame.y1, height)
    for j, yb in enumerate(ys):
        for i, xb in enumerate(xs):
            yield i, j, {"x": xb, "y": yb}


# --------------------------------------------------------------------------- #
# refinement: subdivision is how a pole and a dense mess are told apart
# --------------------------------------------------------------------------- #

def refine(expr: Expr, column: Bounded, depth: int, name: str = "x") -> List[Tuple[Bounded, Enclosure]]:
    """Enclose the column; if Unbounded and depth remains, split it in two and try each half.

    Returns a list of (sub-column, enclosure) covering the column.  Bounded and
    Undefined answers are final: there is nothing to gain by cutting them.
    An Unbounded answer at depth 0 is final too, and is reported as such —
    that is the honest "detail here finer than the column" answer.
    """
    enc = expr.enclose({name: column})
    if depth <= 0 or not isinstance(enc, Unbounded):
        return [(column, enc)]
    mid = (column.lo + column.hi) / 2
    left = Bounded.of(column.lo, mid)
    right = Bounded.of(mid, column.hi)
    return refine(expr, left, depth - 1, name) + refine(expr, right, depth - 1, name)
