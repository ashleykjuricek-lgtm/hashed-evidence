"""
Expressions that enclose themselves.

There is no separate evaluator.  Each node knows how to answer "what values do I
take over this region?" by asking its children and combining their answers with
the propagation law in enclosure.py.  Adding a new function means adding a node.

A region is a Cell: a mapping from variable name to the Bounded stretch it ranges
over.  One variable is the degenerate case of two.

parse(text) turns an ordinary formula string into a tree.  It accepts
    + - * / ** ^   parentheses, unary minus
    sin cos tan exp log ln sqrt abs
    pi e
    any variable name (x, y, t, theta, r, ...)
and nothing else — it is built on Python's own parser, restricted to those forms.
"""

from __future__ import annotations

import ast
import math
from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, Mapping, Union

from .enclosure import Enclosure, Bounded, Unbounded, Undefined

Cell = Mapping[str, Bounded]


class Expr:
    def enclose(self, cell: Cell) -> Enclosure:
        raise NotImplementedError

    def variables(self) -> set:
        raise NotImplementedError

    # convenience for the one-variable case
    def enclose_column(self, column: Bounded, name: str = "x") -> Enclosure:
        return self.enclose({name: column})

    # so people can write a + b on trees when building by hand
    def __add__(self, o): return Add(self, _lift(o))
    def __radd__(self, o): return Add(_lift(o), self)
    def __sub__(self, o): return Sub(self, _lift(o))
    def __rsub__(self, o): return Sub(_lift(o), self)
    def __mul__(self, o): return Mul(self, _lift(o))
    def __rmul__(self, o): return Mul(_lift(o), self)
    def __truediv__(self, o): return Div(self, _lift(o))
    def __rtruediv__(self, o): return Div(_lift(o), self)
    def __pow__(self, o): return Pow(self, _lift(o))
    def __neg__(self): return Neg(self)


def _lift(v) -> "Expr":
    if isinstance(v, Expr):
        return v
    return Const(v)


@dataclass(frozen=True)
class Const(Expr):
    value: Union[int, float, Fraction, str]

    def enclose(self, cell):
        return Bounded.point(self.value)

    def variables(self):
        return set()

    def __str__(self):
        return str(self.value)


@dataclass(frozen=True)
class Var(Expr):
    name: str

    def enclose(self, cell):
        if self.name not in cell:
            raise KeyError(f"variable {self.name!r} is not bound in this cell (have {sorted(cell)})")
        return cell[self.name]

    def variables(self):
        return {self.name}

    def __str__(self):
        return self.name


@dataclass(frozen=True)
class Add(Expr):
    left: Expr
    right: Expr
    def enclose(self, cell): return self.left.enclose(cell).add(self.right.enclose(cell))
    def variables(self): return self.left.variables() | self.right.variables()
    def __str__(self): return f"({self.left} + {self.right})"


@dataclass(frozen=True)
class Sub(Expr):
    left: Expr
    right: Expr
    def enclose(self, cell): return self.left.enclose(cell).sub(self.right.enclose(cell))
    def variables(self): return self.left.variables() | self.right.variables()
    def __str__(self): return f"({self.left} - {self.right})"


@dataclass(frozen=True)
class Mul(Expr):
    left: Expr
    right: Expr
    def enclose(self, cell): return self.left.enclose(cell).mul(self.right.enclose(cell))
    def variables(self): return self.left.variables() | self.right.variables()
    def __str__(self): return f"({self.left} * {self.right})"


@dataclass(frozen=True)
class Div(Expr):
    left: Expr
    right: Expr
    def enclose(self, cell): return self.left.enclose(cell).div(self.right.enclose(cell))
    def variables(self): return self.left.variables() | self.right.variables()
    def __str__(self): return f"({self.left} / {self.right})"


@dataclass(frozen=True)
class Neg(Expr):
    arg: Expr
    def enclose(self, cell): return self.arg.enclose(cell).neg()
    def variables(self): return self.arg.variables()
    def __str__(self): return f"(-{self.arg})"


@dataclass(frozen=True)
class Pow(Expr):
    base: Expr
    exponent: Expr

    def enclose(self, cell):
        b = self.base.enclose(cell)
        folded = fold_fraction(self.exponent)
        if folded is not None:
            # an exact rational exponent, e.g. 2, -1, 1/3, (2/3): use the root/power rules
            return b.power(folded)
        # a variable exponent: a ** e = exp(e * log(a)), with log's domain rules.
        e = self.exponent.enclose(cell)
        return e.mul(b.log()).exp()

    def variables(self): return self.base.variables() | self.exponent.variables()
    def __str__(self): return f"({self.base} ** {self.exponent})"


def _unary(name, method):
    @dataclass(frozen=True)
    class _U(Expr):
        arg: Expr
        def enclose(self, cell): return getattr(self.arg.enclose(cell), method)()
        def variables(self): return self.arg.variables()
        def __str__(self): return f"{name}({self.arg})"
    _U.__name__ = name.capitalize()
    _U.__qualname__ = _U.__name__
    return _U


Sin = _unary("sin", "sin")
Cos = _unary("cos", "cos")
Tan = _unary("tan", "tan")
Exp = _unary("exp", "exp")
Log = _unary("log", "log")
Sqrt = _unary("sqrt", "sqrt")
Abs = _unary("abs", "abs")

_FUNCTIONS = {
    "sin": Sin, "cos": Cos, "tan": Tan, "exp": Exp,
    "log": Log, "ln": Log, "sqrt": Sqrt, "abs": Abs,
}
_CONSTANTS = {"pi": "3.14159265358979323846264338327950288", "e": "2.71828182845904523536028747135266250"}


def fold_fraction(expr: Expr):
    """If the expression is built only from constants with + - * / and unary minus,
    return its exact value as a Fraction; otherwise None."""
    if isinstance(expr, Const):
        return _as_fraction(expr.value)
    if isinstance(expr, Neg):
        v = fold_fraction(expr.arg)
        return None if v is None else -v
    if isinstance(expr, (Add, Sub, Mul, Div)):
        a, b = fold_fraction(expr.left), fold_fraction(expr.right)
        if a is None or b is None:
            return None
        if isinstance(expr, Add): return a + b
        if isinstance(expr, Sub): return a - b
        if isinstance(expr, Mul): return a * b
        return None if b == 0 else a / b
    return None


def _as_fraction(v) -> Fraction:
    if isinstance(v, Fraction):
        return v
    if isinstance(v, int):
        return Fraction(v)
    if isinstance(v, float):
        return Fraction(v).limit_denominator(10**6)
    return Fraction(str(v))


# --------------------------------------------------------------------------- #
# parsing
# --------------------------------------------------------------------------- #

def parse(text: str) -> Expr:
    """Turn a formula string into an expression tree."""
    src = text.replace("^", "**").replace("ω", "w").replace("θ", "theta").replace("π", "pi")
    try:
        tree = ast.parse(src, mode="eval")
    except SyntaxError as e:
        raise ValueError(f"could not read {text!r}: {e.msg} at column {e.offset}") from e
    return _convert(tree.body)


def _convert(node) -> Expr:
    if isinstance(node, ast.Constant):
        if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
            raise ValueError(f"unsupported constant {node.value!r}")
        if isinstance(node.value, float):
            # keep the digits the person typed rather than the binary approximation
            return Const(Fraction(repr(node.value)))
        return Const(node.value)
    if isinstance(node, ast.Name):
        if node.id in _CONSTANTS:
            return Const(_CONSTANTS[node.id])
        return Var(node.id)
    if isinstance(node, ast.UnaryOp):
        if isinstance(node.op, ast.USub):
            return Neg(_convert(node.operand))
        if isinstance(node.op, ast.UAdd):
            return _convert(node.operand)
        raise ValueError("unsupported unary operator")
    if isinstance(node, ast.BinOp):
        l, r = _convert(node.left), _convert(node.right)
        if isinstance(node.op, ast.Add): return Add(l, r)
        if isinstance(node.op, ast.Sub): return Sub(l, r)
        if isinstance(node.op, ast.Mult): return Mul(l, r)
        if isinstance(node.op, ast.Div): return Div(l, r)
        if isinstance(node.op, ast.Pow): return Pow(l, r)
        raise ValueError(f"unsupported operator {type(node.op).__name__}")
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name) or node.func.id not in _FUNCTIONS:
            raise ValueError(f"unknown function in {ast.unparse(node)!r}; have {sorted(_FUNCTIONS)}")
        if len(node.args) != 1 or node.keywords:
            raise ValueError(f"{node.func.id} takes exactly one argument")
        return _FUNCTIONS[node.func.id](_convert(node.args[0]))
    raise ValueError(f"unsupported syntax: {ast.unparse(node)!r}")


# --------------------------------------------------------------------------- #
# a plain float evaluator, used ONLY by the tests to check soundness by sampling
# --------------------------------------------------------------------------- #

def evaluate_float(expr: Expr, env: Dict[str, float]):
    """Return a float, or None where the ordinary functions have no real answer."""
    try:
        if isinstance(expr, Const):
            return float(Fraction(str(expr.value)) if not isinstance(expr.value, (int, float)) else expr.value)
        if isinstance(expr, Var):
            return env[expr.name]
        if isinstance(expr, Neg):
            v = evaluate_float(expr.arg, env)
            return None if v is None else -v
        if isinstance(expr, (Add, Sub, Mul, Div, Pow)):
            a, b = evaluate_float(expr.left if hasattr(expr, "left") else expr.base, env), \
                   evaluate_float(expr.right if hasattr(expr, "right") else expr.exponent, env)
            if a is None or b is None:
                return None
            if isinstance(expr, Add): return a + b
            if isinstance(expr, Sub): return a - b
            if isinstance(expr, Mul): return a * b
            if isinstance(expr, Div): return a / b
            if isinstance(expr, Pow):
                fr = fold_fraction(expr.exponent)
                if fr is not None and fr.denominator > 1 and fr.denominator % 2 == 1 and a < 0:
                    return -((-a) ** float(fr))
                return a ** b
        name = type(expr).__name__.lower()
        v = evaluate_float(expr.arg, env)
        if v is None:
            return None
        return {"sin": math.sin, "cos": math.cos, "tan": math.tan, "exp": math.exp,
                "log": math.log, "sqrt": math.sqrt, "abs": abs}[name](v)
    except (ValueError, ZeroDivisionError, OverflowError):
        return None
    except TypeError:
        return None
