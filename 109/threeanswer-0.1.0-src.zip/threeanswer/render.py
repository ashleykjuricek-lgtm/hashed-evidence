"""
Spans to pixels.  This layer knows nothing about algebra.

Three colours, one per answer, so the picture itself says which answer each
pixel got:

    curve   ink       a bounded stretch, drawn as the vertical box it is
    fill    warm red  unbounded: a pole, or detail finer than a pixel
    (blank) paper     undefined, or simply out of view

raster_curve     y = f(x)          one variable, refined
raster_relation  f(x, y) = 0       Tupper's own use: paint a cell if its enclosure
                                   contains zero; a cell that spills is "maybe"
raster_surface   z = f(x, y)       colour by midpoint; poles and gaps keep their colours
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np

from .enclosure import Bounded, Unbounded, Undefined
from .expr import Expr
from .plot import Frame, Curve, Fill, Blank, classify, columns, cells, refine

# colours as RGBA in 0..1
PAPER = (0.98, 0.97, 0.95, 1.0)
INK = (0.12, 0.13, 0.18, 1.0)
POLE = (0.80, 0.25, 0.20, 1.0)
MAYBE = (0.85, 0.55, 0.50, 1.0)
GRID = (0.85, 0.84, 0.82, 1.0)


def _blank(width: int, height: int) -> np.ndarray:
    img = np.empty((height, width, 4), dtype=float)
    img[:, :] = PAPER
    return img


def _axes(img: np.ndarray, frame: Frame) -> None:
    h, w = img.shape[:2]
    if frame.x0 < 0 < frame.x1:
        col = int((0 - frame.x0) / (frame.x1 - frame.x0) * w)
        img[:, min(col, w - 1)] = GRID
    if frame.y0 < 0 < frame.y1:
        row = int((0 - frame.y0) / (frame.y1 - frame.y0) * h)
        img[h - 1 - min(row, h - 1), :] = GRID


def raster_curve(expr: Expr, frame: Frame, width: int, height: int,
                 depth: int = 6, name: str = "x", axes: bool = True) -> np.ndarray:
    """One variable.  Returns an RGBA image, row 0 at the TOP (image convention)."""
    img = _blank(width, height)
    if axes:
        _axes(img, frame)
    for i, column in enumerate(columns(frame, width)):
        pieces = refine(expr, column, depth, name)
        for sub, enc in pieces:
            span = classify(enc, frame.y0, frame.y1)
            # which pixel columns does this sub-column cover?  at least this one
            c0 = int((float(sub.lo) - frame.x0) / (frame.x1 - frame.x0) * width)
            c1 = int(np.ceil((float(sub.hi) - frame.x0) / (frame.x1 - frame.x0) * width))
            c0, c1 = max(i, c0), min(i + 1, max(c1, c0 + 1))
            if isinstance(span, Fill):
                img[:, c0:c1] = POLE
            elif isinstance(span, Curve):
                r_bottom = int(span.bottom * height)
                r_top = int(np.ceil(span.top * height))
                r_top = max(r_top, r_bottom + 1)
                # image rows count from the top
                img[height - min(r_top, height): height - r_bottom, c0:c1] = INK
    return img


def raster_relation(expr: Expr, frame: Frame, width: int, height: int, axes: bool = True) -> np.ndarray:
    """f(x, y) = 0.  A cell is painted if its enclosure contains zero — the curve
    may pass through here.  A cell whose enclosure spills is painted lighter: it
    might, and the arithmetic cannot say.  Undefined cells stay paper."""
    img = _blank(width, height)
    if axes:
        _axes(img, frame)
    for i, j, cell in cells(frame, width, height):
        enc = expr.enclose(cell)
        row = height - 1 - j
        if isinstance(enc, Bounded) and enc.contains_zero():
            img[row, i] = INK
        elif isinstance(enc, Unbounded):
            img[row, i] = MAYBE
    return img


def raster_surface(expr: Expr, frame: Frame, width: int, height: int,
                   zlo: Optional[float] = None, zhi: Optional[float] = None) -> np.ndarray:
    """z = f(x, y), coloured by the midpoint of each cell's enclosure.
    Poles keep the pole colour; gaps stay paper.  zlo/zhi fix the colour scale."""
    img = _blank(width, height)
    mids = np.full((height, width), np.nan)
    kinds = np.zeros((height, width), dtype=np.uint8)  # 0 undefined, 1 bounded, 2 unbounded
    for i, j, cell in cells(frame, width, height):
        enc = expr.enclose(cell)
        row = height - 1 - j
        if isinstance(enc, Bounded):
            kinds[row, i] = 1
            mids[row, i] = enc.mid()
        elif isinstance(enc, Unbounded):
            kinds[row, i] = 2
    finite = np.isfinite(mids)
    if finite.any():
        lo = np.nanmin(mids) if zlo is None else zlo
        hi = np.nanmax(mids) if zhi is None else zhi
        span = (hi - lo) or 1.0
        t = np.clip((mids - lo) / span, 0, 1)
        # a simple cool-to-warm ramp, no library
        r = 0.15 + 0.75 * t
        g = 0.25 + 0.45 * (1 - np.abs(2 * t - 1))
        b = 0.85 - 0.70 * t
        for ch, v in enumerate((r, g, b)):
            img[..., ch] = np.where(kinds == 1, v, img[..., ch])
    img[kinds == 2] = POLE
    return img


def save_png(img: np.ndarray, path: str, title: Optional[str] = None) -> str:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    h, w = img.shape[:2]
    fig = plt.figure(figsize=(w / 100, h / 100 + (0.4 if title else 0)), dpi=100)
    ax = fig.add_axes([0, 0, 1, h / (h + (40 if title else 0))])
    ax.imshow(img, interpolation="nearest")
    ax.set_axis_off()
    if title:
        fig.text(0.5, 1 - 20 / (h + 40), title, ha="center", va="center", fontsize=10, family="monospace")
    fig.savefig(path, dpi=100)
    plt.close(fig)
    return path


def ascii_curve(expr: Expr, frame: Frame, width: int = 72, height: int = 24,
                depth: int = 6, name: str = "x") -> str:
    """The same picture in text: '#' curve, '|' pole, '.' paper.  Used by the tests."""
    img = raster_curve(expr, frame, width, height, depth, name, axes=False)
    out = []
    for row in img:
        line = []
        for px in row:
            if np.allclose(px, INK): line.append("#")
            elif np.allclose(px, POLE): line.append("|")
            else: line.append(".")
        out.append("".join(line))
    return "\n".join(out)
