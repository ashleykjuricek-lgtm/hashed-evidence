"""
Command line.

    python -m threeanswer "tan(1/x)" --x -1 1 --y -6 6 --out tan.png
    python -m threeanswer "x**2 + y**2 - 1" --relation --x -2 2 --y -2 2 --out circle.png
    python -m threeanswer "1/(x*y)" --surface --x -2 2 --y -2 2 --out hyper.png
    python -m threeanswer "1/x" --x -3 3 --y -5 5 --ascii
    python -m threeanswer "cos(2*theta)" --polar --x -1.2 1.2 --y -1.2 1.2 --out rose.png
    python -m threeanswer "sin(5*theta/2)" --polar --theta 0 4 --out rose52.png
"""

import argparse
import sys
from fractions import Fraction

from .expr import parse
from .plot import Frame
from .render import raster_curve, raster_relation, raster_surface, save_png, ascii_curve
from .polar import raster_polar


def main(argv=None):
    p = argparse.ArgumentParser(prog="threeanswer", description="a plotter with three answers per column")
    p.add_argument("formula")
    p.add_argument("--x", nargs=2, type=float, default=(-5, 5), metavar=("X0", "X1"))
    p.add_argument("--y", nargs=2, type=float, default=(-5, 5), metavar=("Y0", "Y1"))
    p.add_argument("--width", type=int, default=800)
    p.add_argument("--height", type=int, default=500)
    p.add_argument("--depth", type=int, default=6, help="how many times to halve an unbounded column")
    p.add_argument("--var", default="x", help="the variable name for a one-variable curve")
    p.add_argument("--relation", action="store_true", help="plot f(x,y) = 0")
    p.add_argument("--surface", action="store_true", help="plot z = f(x,y) as colour")
    p.add_argument("--polar", action="store_true", help="plot r = f(theta)")
    p.add_argument("--theta", nargs=2, type=Fraction, default=(Fraction(0), Fraction(2)), metavar=("T0", "T1"),
                   help="theta range in multiples of pi, e.g. --theta 0 2 (default) or --theta 0 4 for a half-integer rose")
    p.add_argument("--arcs", type=int, default=720, help="how many arcs to cut the angle into")
    p.add_argument("--ascii", action="store_true", help="print to the terminal instead")
    p.add_argument("--out", default=None)
    a = p.parse_args(argv)

    expr = parse(a.formula)
    frame = Frame(a.x[0], a.x[1], a.y[0], a.y[1])

    if a.ascii:
        print(ascii_curve(expr, frame, 72, 24, a.depth, a.var))
        return 0

    if a.polar:
        img = raster_polar(expr, frame, a.width, a.height, a.theta[0], a.theta[1], a.arcs, a.depth,
                           name=("theta" if a.var == "x" else a.var))
        title = f"r = {a.formula}   theta in [{a.theta[0]}pi, {a.theta[1]}pi]"
    elif a.relation:
        img = raster_relation(expr, frame, a.width, a.height)
        title = f"{a.formula} = 0"
    elif a.surface:
        img = raster_surface(expr, frame, a.width, a.height)
        title = f"z = {a.formula}"
    else:
        img = raster_curve(expr, frame, a.width, a.height, a.depth, a.var)
        title = f"y = {a.formula}"

    out = a.out or "plot.png"
    save_png(img, out, title)
    print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
