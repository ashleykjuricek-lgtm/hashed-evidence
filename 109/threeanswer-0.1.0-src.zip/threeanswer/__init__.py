"""
threeanswer — a plotter that gives one of three answers for every column of pixels,
and never draws a confident line through something it cannot resolve.

The three answers (see enclosure.py):

    Bounded(lo, hi)   the formula's values on this column all lie inside [lo, hi]
    Unbounded         the formula spills to infinity somewhere in this column
                      (a pole, or detail finer than the column can hold)
    Undefined         the formula has no real value anywhere in this column

The rule that joins them: Undefined absorbs, then Unbounded spills, then the
arithmetic runs.  A column with no values is not a column with infinite ones.

Technique: Jeff Tupper, "Reliable Two-Dimensional Graphing Methods for
Mathematical Formulae with Two Free Variables", SIGGRAPH 2001.  Evaluate over a
region with interval arithmetic instead of at a point.

Design read from James Watkins's public vexelray-gui-plot module
(github.com/sibarum/vexelray-gui, master, docs/reliable-plotting.md), which
carries the same three answers and the same absorb/spill law.  This is a
re-implementation of the idea in Python, not a port of his code.
"""

from .enclosure import Enclosure, Bounded, Unbounded, Undefined
from .expr import parse, Expr
from .plot import Frame, Span, Curve, Fill, Blank, classify, columns, cells, refine
from .render import raster_curve, raster_relation, raster_surface, save_png, ascii_curve
from .polar import raster_polar

__all__ = [
    "Enclosure", "Bounded", "Unbounded", "Undefined",
    "parse", "Expr",
    "Frame", "Span", "Curve", "Fill", "Blank", "classify", "columns", "cells", "refine",
    "raster_curve", "raster_relation", "raster_surface", "save_png", "ascii_curve",
    "raster_polar",
]
