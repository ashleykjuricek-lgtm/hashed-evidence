"""
Polar mode: r = f(theta), for roses and anything else with tails.

The angle is cut into arcs the way x was cut into columns.  Each arc is asked
"what values does r take over this whole arc?" and gets the same three answers:

    Bounded(rlo, rhi)  paint the annular sector {theta in arc, r in [rlo, rhi]}
    Unbounded          paint the whole ray at that arc, in the pole colour
    Undefined          paint nothing

Negative r is not clipped and not abs'd.  A point (r, theta) with r < 0 is the
point (|r|, theta + pi), so the negative part of an enclosure is folded across to
the opposite arc exactly.  A rose with an even number of petals is drawn whole
because of this, not in spite of it.

Painting is by pixel CELLS, not pixel centres: a pixel is painted if the set of
(r, theta) pairs it covers intersects a sector.  So a thin curve that clips a
pixel's corner still paints that pixel.  The tests check this by sampling the
true curve and asking that every sampled point lands on a painted pixel.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction
from typing import List, Tuple

import numpy as np
from mpmath import iv

from .enclosure import Bounded, Unbounded, Undefined
from .expr import Expr
from .plot import Frame, refine
from .render import PAPER, INK, POLE, _blank, _axes

TWO_PI = 2 * math.pi


@dataclass(frozen=True)
class Sector:
    """theta in [tlo, thi] (radians, already reduced so 0 <= tlo <= thi <= 2pi), r in [rlo, rhi]."""
    tlo: float
    thi: float
    rlo: float
    rhi: float
    pole: bool


# --------------------------------------------------------------------------- #
# arcs
# --------------------------------------------------------------------------- #

def arcs(theta0_pi: Fraction, theta1_pi: Fraction, n: int) -> List[Bounded]:
    """Cut [theta0*pi, theta1*pi] into n arcs.  The endpoints are multiples of pi
    computed as intervals, so neighbouring arcs overlap by a rounding sliver and
    nothing falls between them."""
    step = (Fraction(theta1_pi) - Fraction(theta0_pi)) / n
    out = []
    for k in range(n):
        a = iv.pi * _mpq(Fraction(theta0_pi) + k * step)
        b = iv.pi * _mpq(Fraction(theta0_pi) + (k + 1) * step)
        out.append(Bounded.of_mpi(iv.mpf([a.a, b.b])))
    return out


def _mpq(f: Fraction):
    return iv.mpf(f.numerator) / f.denominator


# --------------------------------------------------------------------------- #
# from enclosures to sectors
# --------------------------------------------------------------------------- #

def sectors(expr: Expr, theta0_pi, theta1_pi, n_arcs: int, depth: int, r_cap: float,
            name: str = "theta") -> List[Sector]:
    """Enclose r over every arc (refined), fold negative r across, reduce theta mod 2pi."""
    out: List[Sector] = []
    for arc in arcs(theta0_pi, theta1_pi, n_arcs):
        for sub, enc in refine(expr, arc, depth, name):
            tlo, thi = float(sub.lo), float(sub.hi)
            if isinstance(enc, Undefined):
                continue
            if isinstance(enc, Unbounded):
                _emit(out, tlo, thi, 0.0, r_cap, True)
                continue
            rlo, rhi = float(enc.lo), float(enc.hi)
            if rhi > 0:
                _emit(out, tlo, thi, max(rlo, 0.0), min(rhi, r_cap), False)
            if rlo < 0:
                # r < 0 lives at theta + pi with radius |r|
                _emit(out, tlo + math.pi, thi + math.pi, max(-rhi, 0.0), min(-rlo, r_cap), False)
    return out


def _emit(out: List[Sector], tlo: float, thi: float, rlo: float, rhi: float, pole: bool) -> None:
    """Reduce [tlo, thi] into [0, 2pi], splitting at the seam if it wraps."""
    if thi - tlo >= TWO_PI:
        out.append(Sector(0.0, TWO_PI, rlo, rhi, pole))
        return
    a = tlo % TWO_PI
    b = a + (thi - tlo)
    if b <= TWO_PI:
        out.append(Sector(a, b, rlo, rhi, pole))
    else:
        out.append(Sector(a, TWO_PI, rlo, rhi, pole))
        out.append(Sector(0.0, b - TWO_PI, rlo, rhi, pole))


# --------------------------------------------------------------------------- #
# pixel cells in polar terms
# --------------------------------------------------------------------------- #

def _pixel_polar(frame: Frame, width: int, height: int):
    """For every pixel cell: rmin, rmax, and its theta coverage as up to two
    non-wrapping ranges [t1lo,t1hi] and [t2lo,t2hi] (second empty when unused),
    plus a flag for cells that contain the origin (which cover every angle)."""
    xs = np.linspace(frame.x0, frame.x1, width + 1)
    ys = np.linspace(frame.y0, frame.y1, height + 1)
    x0 = xs[:-1][None, :]; x1 = xs[1:][None, :]
    # image row 0 is the TOP, so rows run from y1 down to y0
    y1 = ys[::-1][:-1][:, None]; y0 = ys[::-1][1:][:, None]
    x0 = np.broadcast_to(x0, (height, width)); x1 = np.broadcast_to(x1, (height, width))
    y0 = np.broadcast_to(y0, (height, width)); y1 = np.broadcast_to(y1, (height, width))

    dx = np.maximum.reduce([x0, np.zeros_like(x0), -x1])
    dy = np.maximum.reduce([y0, np.zeros_like(y0), -y1])
    rmin = np.hypot(dx, dy)
    rmax = np.sqrt(np.maximum.reduce([x0 * x0, x1 * x1]) + np.maximum.reduce([y0 * y0, y1 * y1]))
    origin = (x0 <= 0) & (0 <= x1) & (y0 <= 0) & (0 <= y1)

    corners = np.stack([np.arctan2(y0, x0), np.arctan2(y0, x1), np.arctan2(y1, x0), np.arctan2(y1, x1)]) % TWO_PI
    tmin = corners.min(axis=0)
    tmax = corners.max(axis=0)
    wraps = (tmax - tmin) > math.pi
    # non-wrapping: one range [tmin, tmax].  wrapping: the cell straddles angle 0,
    # so its coverage is [largest-below-seam, 2pi] and [0, smallest-above-seam].
    # For a wrapping cell the covered angles are those >= (min angle above pi) or <= (max angle below pi).
    above = np.where(corners > math.pi, corners, np.inf).min(axis=0)
    below = np.where(corners <= math.pi, corners, -np.inf).max(axis=0)
    t1lo = np.where(wraps, above, tmin)
    t1hi = np.where(wraps, TWO_PI, tmax)
    t2lo = np.where(wraps, 0.0, 1.0)
    t2hi = np.where(wraps, below, 0.0)   # empty range (lo > hi) when not wrapping
    return rmin, rmax, t1lo, t1hi, t2lo, t2hi, origin


# --------------------------------------------------------------------------- #
# the raster
# --------------------------------------------------------------------------- #

def raster_polar(expr: Expr, frame: Frame, width: int, height: int,
                 theta0_pi=0, theta1_pi=2, n_arcs: int = 720, depth: int = 6,
                 name: str = "theta", axes: bool = True) -> np.ndarray:
    """r = f(theta) over theta in [theta0*pi, theta1*pi].  RGBA image, row 0 at the top."""
    img = _blank(width, height)
    if axes:
        _axes(img, frame)
    r_cap = math.hypot(max(abs(frame.x0), abs(frame.x1)), max(abs(frame.y0), abs(frame.y1))) * 1.01
    secs = sectors(expr, theta0_pi, theta1_pi, n_arcs, depth, r_cap, name)
    rmin, rmax, t1lo, t1hi, t2lo, t2hi, origin = _pixel_polar(frame, width, height)

    sx = width / (frame.x1 - frame.x0)
    sy = height / (frame.y1 - frame.y0)
    ink_mask = np.zeros((height, width), dtype=bool)
    pole_mask = np.zeros((height, width), dtype=bool)

    for s in secs:
        # bounding box of the sector in pixel space, so the test runs on a small window
        c0, c1, r0, r1 = _bbox(s, frame, width, height, sx, sy)
        if c1 <= c0 or r1 <= r0:
            continue
        win = (slice(r0, r1), slice(c0, c1))
        r_ok = (rmax[win] >= s.rlo) & (rmin[win] <= s.rhi)
        t_ok = ((t1lo[win] <= s.thi) & (s.tlo <= t1hi[win])) | ((t2lo[win] <= s.thi) & (s.tlo <= t2hi[win]))
        hit = r_ok & (t_ok | origin[win])
        if s.pole:
            pole_mask[win] |= hit
        else:
            ink_mask[win] |= hit

    img[ink_mask] = INK
    img[pole_mask] = POLE   # a pole is the louder answer; it paints over ink
    return img


def _bbox(s: Sector, frame: Frame, width: int, height: int, sx: float, sy: float):
    pts = [(r * math.cos(t), r * math.sin(t)) for r in (s.rlo, s.rhi) for t in (s.tlo, s.thi)]
    for k in range(5):
        axis_angle = k * math.pi / 2
        if s.tlo <= axis_angle <= s.thi:
            pts.append((s.rhi * math.cos(axis_angle), s.rhi * math.sin(axis_angle)))
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    c0 = int(math.floor((min(xs) - frame.x0) * sx)) - 1
    c1 = int(math.ceil((max(xs) - frame.x0) * sx)) + 1
    r_top = int(math.floor((frame.y1 - max(ys)) * sy)) - 1
    r_bot = int(math.ceil((frame.y1 - min(ys)) * sy)) + 1
    return max(c0, 0), min(c1, width), max(r_top, 0), min(r_bot, height)
