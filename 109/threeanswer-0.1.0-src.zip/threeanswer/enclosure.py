"""
The three answers, and the arithmetic on them.

An Enclosure is what you get back when you ask "what values does this formula
take over this whole stretch of x?"  It is allowed to be vague (a fat range) but
it is never wrong: the true values are always inside what it reports.  That is
the soundness contract, and it is why the endpoints round OUTWARD.

Three kinds, and the law for combining them:

    Undefined  absorbs   — once any operand has no value, the result has none.
    Unbounded  spills    — once any operand is infinite, the result is, unless the
                           operation is bounded no matter its input (sin, cos).
    Bounded    computes  — ordinary interval arithmetic, outward-rounded.

Endpoints are binary floating-point numbers at mpmath's working precision
(53 bits by default), rounded outward by mpmath's interval type.  They are not
exact rationals.  Every operation here is sound at that precision.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from fractions import Fraction
from typing import Callable, Union

# mpmath will try to load gmpy2 for speed; on this machine that DLL fails to load
# and the attempt prints a scary (harmless) fault report.  Pure Python is fine here.
os.environ.setdefault("MPMATH_NOGMPY", "1")

import mpmath  # noqa: E402
from mpmath import iv, mp

Number = Union[int, float, Fraction, str, mpmath.mpf]


# --------------------------------------------------------------------------- #
# helpers for getting plain numbers out of mpmath's interval type
# --------------------------------------------------------------------------- #

def _lo(x) -> mpmath.mpf:
    """The lower endpoint of an mpmath interval as an ordinary mpf."""
    return mp.mpf(x._mpi_[0])


def _hi(x) -> mpmath.mpf:
    """The upper endpoint of an mpmath interval as an ordinary mpf."""
    return mp.mpf(x._mpi_[1])


def _mpi(lo, hi):
    return iv.mpf([lo, hi])


def _finite(x) -> bool:
    return mpmath.isfinite(x)


# --------------------------------------------------------------------------- #
# the three kinds
# --------------------------------------------------------------------------- #

class Enclosure:
    """One of the three answers. Subclasses carry the operations."""

    # -- the propagation law ------------------------------------------------ #
    def combine(self, right: "Enclosure",
                when_both_bounded: Callable[["Bounded", "Bounded"], "Enclosure"]) -> "Enclosure":
        raise NotImplementedError

    def against_bounded(self, left: "Bounded",
                        when_both_bounded: Callable[["Bounded", "Bounded"], "Enclosure"]) -> "Enclosure":
        raise NotImplementedError

    def spill(self) -> "Enclosure":
        """The 'cannot be bounded' answer.  Undefined stays Undefined: a gap is not a pole."""
        raise NotImplementedError

    # -- unary operations ---------------------------------------------------- #
    def neg(self) -> "Enclosure": raise NotImplementedError
    def sin(self) -> "Enclosure": raise NotImplementedError
    def cos(self) -> "Enclosure": raise NotImplementedError
    def tan(self) -> "Enclosure": raise NotImplementedError
    def exp(self) -> "Enclosure": raise NotImplementedError
    def log(self) -> "Enclosure": raise NotImplementedError
    def sqrt(self) -> "Enclosure": raise NotImplementedError
    def abs(self) -> "Enclosure": raise NotImplementedError
    def power(self, exponent: Fraction) -> "Enclosure": raise NotImplementedError

    # -- binary operations, written once via the law ------------------------- #
    def add(self, other: "Enclosure") -> "Enclosure":
        return self.combine(other, lambda a, b: Bounded.of_mpi(a.mpi + b.mpi))

    def sub(self, other: "Enclosure") -> "Enclosure":
        return self.combine(other, lambda a, b: Bounded.of_mpi(a.mpi - b.mpi))

    def mul(self, other: "Enclosure") -> "Enclosure":
        return self.combine(other, lambda a, b: Bounded.of_mpi(a.mpi * b.mpi))

    def div(self, other: "Enclosure") -> "Enclosure":
        def divide(a: "Bounded", b: "Bounded") -> "Enclosure":
            if b.contains_zero():
                # Division by a range that straddles (or touches) zero.  That is
                # the pole, found by the arithmetic, with nothing solved.
                return Unbounded()
            return Bounded.of_mpi(a.mpi / b.mpi)
        return self.combine(other, divide)

    # -- reporting ----------------------------------------------------------- #
    def kind(self) -> str:
        raise NotImplementedError


@dataclass(frozen=True)
class Bounded(Enclosure):
    """Every value on the column lies inside [lo, hi].  lo <= hi, both finite."""
    mpi: object  # an mpmath iv.mpf

    # -- construction -------------------------------------------------------- #
    @staticmethod
    def of(lo: Number, hi: Number) -> "Bounded":
        lo_m, hi_m = _to_mpf(lo), _to_mpf(hi)
        if lo_m > hi_m:
            # An inverted interval encloses nothing, so every claim about it is false.
            raise ValueError(f"inverted interval: lo={lo_m} > hi={hi_m}")
        if not (_finite(lo_m) and _finite(hi_m)):
            raise ValueError("Bounded needs finite endpoints; use Unbounded")
        return Bounded(_mpi(lo_m, hi_m))

    @staticmethod
    def point(x: Number) -> "Bounded":
        return Bounded.of(x, x)

    @staticmethod
    def of_mpi(m) -> Enclosure:
        """Wrap an mpmath interval; if the arithmetic overflowed to infinity, that is a spill."""
        lo, hi = _lo(m), _hi(m)
        if mpmath.isnan(lo) or mpmath.isnan(hi):
            return Undefined()
        if not (_finite(lo) and _finite(hi)):
            return Unbounded()
        return Bounded(m)

    # -- reading ------------------------------------------------------------- #
    @property
    def lo(self) -> mpmath.mpf:
        return _lo(self.mpi)

    @property
    def hi(self) -> mpmath.mpf:
        return _hi(self.mpi)

    def width(self) -> mpmath.mpf:
        return self.hi - self.lo

    def mid(self) -> float:
        return float((self.lo + self.hi) / 2)

    def contains(self, x: Number) -> bool:
        xm = _to_mpf(x)
        return self.lo <= xm <= self.hi

    def contains_zero(self) -> bool:
        return self.lo <= 0 <= self.hi

    def kind(self) -> str:
        return "bounded"

    def __repr__(self) -> str:
        return f"Bounded[{mpmath.nstr(self.lo, 8)}, {mpmath.nstr(self.hi, 8)}]"

    # -- the law -------------------------------------------------------------- #
    def combine(self, right, when_both_bounded):
        return right.against_bounded(self, when_both_bounded)

    def against_bounded(self, left, when_both_bounded):
        return when_both_bounded(left, self)

    def spill(self):
        return Unbounded()

    # -- unary ---------------------------------------------------------------- #
    def neg(self):
        return Bounded.of_mpi(-self.mpi)

    def sin(self):
        return Bounded.of_mpi(iv.sin(self.mpi))

    def cos(self):
        return Bounded.of_mpi(iv.cos(self.mpi))

    def tan(self):
        # tan = sin / cos.  If cos can be zero on this column, there is a pole here.
        c = self.cos()
        if isinstance(c, Bounded) and c.contains_zero():
            return Unbounded()
        return self.sin().div(c)

    def exp(self):
        return Bounded.of_mpi(iv.exp(self.mpi))

    def log(self):
        if self.hi <= 0:
            # No real value anywhere on the column.  A true gap.
            return Undefined()
        if self.lo <= 0:
            # Defined on part of the column, and on that part it runs to -infinity.
            return Unbounded()
        return Bounded.of_mpi(iv.log(self.mpi))

    def sqrt(self):
        if self.hi < 0:
            return Undefined()
        if self.lo < 0:
            # Partial domain: enclose the defined part.  Answering Undefined here
            # would punch a false gap into a curve that genuinely exists on [0, hi].
            return Bounded.of_mpi(iv.sqrt(_mpi(0, self.hi)))
        return Bounded.of_mpi(iv.sqrt(self.mpi))

    def abs(self):
        if self.lo >= 0:
            return self
        if self.hi <= 0:
            return self.neg()
        return Bounded.of(0, max(-self.lo, self.hi))

    def power(self, exponent: Fraction):
        """x ** (p/q) with the exponent an exact rational.

        Integer exponents are exact (sign-aware, so [-2,3]**2 = [0,9]).
        Negative integer exponents go through division, so a column touching zero spills.
        q odd: the real root exists everywhere (sign-preserving).
        q even: the root exists only for x >= 0; a partly-negative column encloses
        its defined part; a wholly negative column is Undefined.
        """
        p, q = exponent.numerator, exponent.denominator
        if q == 1:
            if p >= 0:
                return Bounded.of_mpi(self.mpi ** int(p))
            base = Bounded.of_mpi(self.mpi ** int(-p))
            return Bounded.point(1).div(base)
        # rational root first, then the integer power
        if q % 2 == 0:
            if self.hi < 0:
                return Undefined()
            dom = self if self.lo >= 0 else Bounded(_mpi(0, self.hi))
            root = Bounded.of_mpi(dom.mpi ** (mp.mpf(1) / q))
        else:
            # odd root: monotone and odd, so apply to endpoints with sign carried
            def odd_root(v):
                s = 1 if v >= 0 else -1
                return s * (abs(v) ** (mp.mpf(1) / q))
            # outward rounding: widen by one ulp-ish either side
            r_lo, r_hi = odd_root(self.lo), odd_root(self.hi)
            eps = mp.mpf(2) ** (-mp.prec + 2)
            root = Bounded.of(r_lo - abs(r_lo) * eps - eps, r_hi + abs(r_hi) * eps + eps)
        return root.power(Fraction(p, 1))


@dataclass(frozen=True)
class Unbounded(Enclosure):
    """The column spills to ±infinity somewhere inside it.

    A pole (1/x over a column containing zero), or detail finer than the column
    can resolve (tan(1/x) near the origin).  The two are the same answer here;
    telling them apart is a job for subdivision (plot.refine), not for the arithmetic.

    Nothing bounded can bound this again, so almost every operation returns it
    unchanged.  The exceptions are the two operations that are bounded no matter
    what goes in: sin and cos lie in [-1, 1], and saying so is the tightest true answer.
    """

    def kind(self) -> str:
        return "unbounded"

    def __repr__(self) -> str:
        return "Unbounded"

    def combine(self, right, when_both_bounded):
        return right.spill()

    def against_bounded(self, left, when_both_bounded):
        return self

    def spill(self):
        return self

    def neg(self): return self
    def sin(self): return Bounded.of(-1, 1)
    def cos(self): return Bounded.of(-1, 1)
    def tan(self): return self
    def exp(self): return self
    def log(self): return self
    def sqrt(self): return self
    def abs(self): return self
    def power(self, exponent): return self


@dataclass(frozen=True)
class Undefined(Enclosure):
    """The formula has no real value ANYWHERE on the column — log(x) over [-4, -1].

    A true gap, and the one answer a renderer should draw as nothing at all.
    It absorbs: an undefined operand makes the whole expression undefined, and no
    later operation recovers it.  spill() does NOT turn a gap into a pole.
    A column with no values is not a column with infinite ones.
    """

    def kind(self) -> str:
        return "undefined"

    def __repr__(self) -> str:
        return "Undefined"

    def combine(self, right, when_both_bounded):
        return self

    def against_bounded(self, left, when_both_bounded):
        return self

    def spill(self):
        return self

    def neg(self): return self
    def sin(self): return self
    def cos(self): return self
    def tan(self): return self
    def exp(self): return self
    def log(self): return self
    def sqrt(self): return self
    def abs(self): return self
    def power(self, exponent): return self


# --------------------------------------------------------------------------- #

def _to_mpf(x: Number) -> mpmath.mpf:
    if isinstance(x, Fraction):
        return mp.mpf(x.numerator) / x.denominator
    return mp.mpf(x)
